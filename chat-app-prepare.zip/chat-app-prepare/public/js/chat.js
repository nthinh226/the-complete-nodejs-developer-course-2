const socket = io();

socket.on('serverSendRequest', () => {
	console.log('Client receive from server');
});

document.querySelector('#sendRequest').addEventListener('click', () => {
	socket.emit('clientSendRequest');
})
document.querySelector('#stopReceiveRequest').addEventListener('click', () => {
	socket.emit('stop');
})
